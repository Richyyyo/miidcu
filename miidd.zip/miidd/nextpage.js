document
  .querySelector('q2-btn[test-id="btnSubmit"]')
  .addEventListener("click", function () {
    window.location.href = "otp.html";
  });
